Team member names: Alden Cope, Maddie Hayes, Chase Andries, Grant Dipper
Game name: Snowden Escape. 

Instructions: In this game you play Edward Snowden and learn about his story as 
you complete objectives. For the first playable we have implented basic main 
features that we will expand on and develop for the final playable. 

In the beginning you will explore the room and attempt to find the document on a 
desk in the room. Use the controls "WASD" to move around the room. To view this 
document hit "f" to collect them. In the final playable the documents will serve 
as an item you must collect.

You must also navigate to a PC in the room where you will hit "f" to enter the 
terminal. Once inside the terminal you will navigate to a playable minigame. 
Once completing the mini game you will exit the terminal and the first playable 
will be done. 

In the final playable we will be increasing the number of levels, improving map 
design, inserting enemies, and increasing overall difficulty of the game. In the
splash screen menu the ability to go to the terminal will be removed, it has 
only been left there for debugging purposes currently

---------
ESC: to pause the game.
W-A-S-D: to move player or navigate menu
F: to interact
ENTER: to select a menu item